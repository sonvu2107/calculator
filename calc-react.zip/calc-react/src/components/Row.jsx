export default function Row({children}) {
  return <div className="grid grid-cols-4 gap-2">{children}</div>;
}
